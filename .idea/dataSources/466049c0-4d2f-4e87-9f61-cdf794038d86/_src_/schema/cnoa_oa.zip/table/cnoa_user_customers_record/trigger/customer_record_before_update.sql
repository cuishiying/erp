CREATE TRIGGER customer_record_before_update
BEFORE UPDATE ON cnoa_user_customers_record
FOR EACH ROW
  BEGIN
    UPDATE cnoa_user_customers SET newtime = unix_timestamp() WHERE cid = NEW.cid;     
  END;
