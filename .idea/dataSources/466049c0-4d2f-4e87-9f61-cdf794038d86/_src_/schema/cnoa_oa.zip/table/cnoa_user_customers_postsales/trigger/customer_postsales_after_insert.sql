CREATE TRIGGER customer_postsales_after_insert
AFTER INSERT ON cnoa_user_customers_postsales
FOR EACH ROW
  BEGIN
    UPDATE cnoa_user_customers SET newtime = unix_timestamp() WHERE cid = NEW.cid;     
  END;
