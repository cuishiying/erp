CREATE TRIGGER customer_presales_after_delete
AFTER DELETE ON cnoa_user_customers_presales
FOR EACH ROW
  BEGIN
    UPDATE cnoa_user_customers SET followNum=followNum-1 WHERE cid = OLD.cid;     
  END;
