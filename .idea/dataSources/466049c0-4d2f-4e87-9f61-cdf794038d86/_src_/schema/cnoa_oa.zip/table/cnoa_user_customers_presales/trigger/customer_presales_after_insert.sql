CREATE TRIGGER customer_presales_after_insert
AFTER INSERT ON cnoa_user_customers_presales
FOR EACH ROW
  BEGIN
    UPDATE cnoa_user_customers SET newtime = unix_timestamp(), followNum=followNum+1 WHERE cid = NEW.cid;     
  END;
