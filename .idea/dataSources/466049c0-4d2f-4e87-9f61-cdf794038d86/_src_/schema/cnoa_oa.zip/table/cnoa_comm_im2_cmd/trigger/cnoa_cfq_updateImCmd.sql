CREATE TRIGGER cnoa_cfq_updateImCmd
AFTER INSERT ON cnoa_comm_im2_cmd
FOR EACH ROW
  BEGIN
UPDATE `cnoa_comm_im2_scantime` SET `newcmd`='1' WHERE `uid`=NEW.`uid`;
END;
