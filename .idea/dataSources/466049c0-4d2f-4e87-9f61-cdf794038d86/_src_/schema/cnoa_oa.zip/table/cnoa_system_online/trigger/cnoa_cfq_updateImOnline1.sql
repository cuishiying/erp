CREATE TRIGGER cnoa_cfq_updateImOnline1
AFTER INSERT ON cnoa_system_online
FOR EACH ROW
  BEGIN
UPDATE `cnoa_comm_im2_scantime` SET `uol`='1';
END;
