CREATE TRIGGER cnoa_afterinsert_on_cnoa_jxc_stock_chuku
AFTER INSERT ON cnoa_jxc_stock_chuku
FOR EACH ROW
  begin
	   insert into cnoa_jxc_temp(uFlowId) values(new.uFlowId);
	   insert into cnoa_jxc_stock_goods_detail(uFlowId,quantity) select uFlowId,D_17 from cnoa_z_wf_d_3_29 where uFlowId = NEW.uFlowId;
	   update cnoa_jxc_stock_goods_detail set storageId = (select storageId from cnoa_jxc_stock_chuku where storageId = NEW.storageId),goodsId = (select bindId from cnoa_z_wf_d_3_29 where uFlowId = NEW.uFlowId) where uFlowId = NEW.uFlowId; 
end;
